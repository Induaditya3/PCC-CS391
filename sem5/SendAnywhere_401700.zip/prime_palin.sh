#!/bin/bash

echo "Enter M:"
read M

echo "Enter N:"
read N

echo "1. Print Prime Numbers"
echo "2. Print Palindrome Numbers"
echo "3. Print Both Prime and Palindrome Numbers"
echo "Enter your choice:"
read choice

is_prime()
{
    num=$1

    if [ $num -lt 2 ]; then
        return 1
    fi

    for ((i=2; i*i<=num; i++))
    do
        if [ $((num%i)) -eq 0 ]; then
            return 1
        fi
    done

    return 0
}

is_palindrome()
{
    num=$1
    temp=$num
    rev=0

    while [ $temp -gt 0 ]
    do
        digit=$((temp % 10))
        rev=$((rev * 10 + digit))
        temp=$((temp / 10))
    done

    if [ $num -eq $rev ]; then
        return 0
    else
        return 1
    fi
}

case $choice in

1)
    echo "Prime numbers:"
    for ((num=M; num<=N; num++))
    do
        if is_prime $num
        then
            echo -n "$num "
        fi
    done
    echo
    ;;

2)
    echo "Palindrome numbers:"
    for ((num=M; num<=N; num++))
    do
        if is_palindrome $num
        then
            echo -n "$num "
        fi
    done
    echo
    ;;

3)
    echo "Prime and Palindrome numbers:"
    for ((num=M; num<=N; num++))
    do
        if is_prime $num && is_palindrome $num
        then
            echo -n "$num "
        fi
    done
    echo
    ;;

*)
    echo "Invalid choice"
    ;;

esac