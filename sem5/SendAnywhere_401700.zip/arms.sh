#!/bin/bash

echo "Enter M:"
read M

echo "Enter N:"
read N

echo "Armstrong numbers between $M and $N:"

for ((num=M; num<=N; num++))
do
    temp=$num
    digits=${#num}
    sum=0

    while [ $temp -gt 0 ]
    do
        digit=$((temp % 10))

        power=1

        for ((i=1; i<=digits; i++))
        do
            power=$((power * digit))
        done

        sum=$((sum + power))
        temp=$((temp / 10))
    done

    if [ $sum -eq $num ]
    then
        echo -n "$num "
    fi
done

echo