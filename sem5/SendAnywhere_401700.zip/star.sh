#!/bin/bash

for ((i=1; i<=5; i++))
do
    # Print stars
    for ((j=1; j<=i; j++))
    do
        echo -n "*"
    done

    echo -n "    "

    # Print number i, i times
    for ((j=1; j<=i; j++))
    do
        echo -n "$i"
    done

    echo
done