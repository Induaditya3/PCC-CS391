#!/bin/bash

echo "Enter Traffic Light Colour:"
read colour

colour=$(echo "$colour" | tr '[:upper:]' '[:lower:]')

case $colour in

red)
    echo "STOP"
    ;;

yellow)
    echo "WAIT / GET READY"
    ;;

green)
    echo "GO"
    ;;

*)
    echo "Invalid traffic light colour"
    ;;

esac